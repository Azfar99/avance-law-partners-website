// Avance Law Partners. Dynamic SEO Meta Tag Injector
export function updatePageSEO({
  title,
  description,
  ogImage,
  canonicalUrl,
}: {
  title?: string
  description?: string
  ogImage?: string
  canonicalUrl?: string
}) {
  if (title) {
    document.title = title.includes("Avance Law Partners")
      ? title
      : `${title} | Avance Law Partners`
  }

  if (description) {
    let metaDesc = document.querySelector('meta[name="description"]')
    if (!metaDesc) {
      metaDesc = document.createElement("meta")
      metaDesc.setAttribute("name", "description")
      document.head.appendChild(metaDesc)
    }
    metaDesc.setAttribute("content", description)
  }

  for (const [property, content] of [
    ["og:title", document.title],
    ["og:description", description],
  ] as const) {
    if (!content) continue
    let meta = document.querySelector(`meta[property="${property}"]`)
    if (!meta) {
      meta = document.createElement("meta")
      meta.setAttribute("property", property)
      document.head.appendChild(meta)
    }
    meta.setAttribute("content", content)
  }

  if (ogImage) {
    let ogImg = document.querySelector('meta[property="og:image"]')
    if (!ogImg) {
      ogImg = document.createElement("meta")
      ogImg.setAttribute("property", "og:image")
      document.head.appendChild(ogImg)
    }
    ogImg.setAttribute("content", ogImage)
  }

  if (canonicalUrl) {
    let linkCan = document.querySelector('link[rel="canonical"]')
    if (!linkCan) {
      linkCan = document.createElement("link")
      linkCan.setAttribute("rel", "canonical")
      document.head.appendChild(linkCan)
    }
    linkCan.setAttribute("href", canonicalUrl)
  }
}
