// Avance Law Partners. Universal Supabase Client
// Connects to real Supabase via REST/Auth/Storage API when credentials are provided.
// Falls back gracefully to local storage persistence when running offline or during preview.

const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL || "").replace(
  /\/$/,
  "",
)
const SUPABASE_ANON_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  ""

export const isConfigured = Boolean(
  SUPABASE_URL && SUPABASE_ANON_KEY && !SUPABASE_URL.includes("your-project"),
)

function getSupabaseHeaders(
  sessionToken?: string,
  contentType?: string,
): Record<string, string> {
  const headers: Record<string, string> = { apikey: SUPABASE_ANON_KEY }
  if (contentType) headers["Content-Type"] = contentType

  // New sb_publishable_* keys are API keys, not JWTs. Keep Bearer auth only
  // for an actual user session or the legacy JWT-format anon key.
  const authorizationToken =
    sessionToken ||
    (SUPABASE_ANON_KEY.startsWith("eyJ") ? SUPABASE_ANON_KEY : "")
  if (authorizationToken) headers.Authorization = `Bearer ${authorizationToken}`
  return headers
}

export async function invokeEdgeFunction<T>(
  name: string,
  body: unknown,
): Promise<T> {
  if (!isConfigured) {
    throw new Error("This preview is not connected to the enquiry service yet.")
  }

  let response: Response
  try {
    response = await fetch(`${SUPABASE_URL}/functions/v1/${name}`, {
      method: "POST",
      headers: getSupabaseHeaders(undefined, "application/json"),
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    })
  } catch {
    throw new Error(
      "We could not confirm delivery. Please contact the firm by phone or email before sending again.",
    )
  }

  const result = await response.json().catch(() => null)
  if (!response.ok) {
    const message =
      typeof result?.error === "string"
        ? result.error
        : "We could not send your enquiry right now. Please try again."
    throw new Error(message)
  }

  return result as T
}

// Local Mock Storage Key
const LOCAL_STORAGE_PREFIX = "alp_db_"

export function hasLocalTable(table: string): boolean {
  try {
    return Array.isArray(
      JSON.parse(localStorage.getItem(LOCAL_STORAGE_PREFIX + table) || "null"),
    )
  } catch {
    return false
  }
}

function getLocalTable<T>(table: string, defaultData: T[] = []): T[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_PREFIX + table)
    if (raw) {
      const parsed = JSON.parse(raw)
      if (Array.isArray(parsed)) return parsed
    }
  } catch (e) {
    console.warn("Could not read local table", table, e)
  }
  return defaultData
}

function setLocalTable<T>(table: string, data: T[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + table, JSON.stringify(data))
  } catch (e) {
    console.warn("Could not save local table", table, e)
  }
}

// Token management for Auth
const AUTH_TOKEN_KEY = "alp_auth_token"
const AUTH_USER_KEY = "alp_auth_user"

export function getStoredSession() {
  try {
    const token = localStorage.getItem(AUTH_TOKEN_KEY)
    const userStr = localStorage.getItem(AUTH_USER_KEY)
    if (
      token &&
      userStr &&
      (import.meta.env.DEV || token !== "local-jwt-token-preview")
    ) {
      return { token, user: JSON.parse(userStr) }
    }
  } catch (e) {
    // ignore
  }
  return null
}

export function setStoredSession(token: string | null, user: any | null) {
  if (token && user) {
    localStorage.setItem(AUTH_TOKEN_KEY, token)
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user))
  } else {
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(AUTH_USER_KEY)
  }
  authListeners.forEach((fn) =>
    fn(
      user ? "SIGNED_IN" : "SIGNED_OUT",
      user ? { user, access_token: token } : null,
    ),
  )
}

const authListeners: Array<(event: string, session: any) => void> = []

interface QueryResult {
  data: any
  error: any
}

class QueryBuilder {
  private operation: "select" | "update" | "delete" = "select"
  private patch: any
  private table: string
  private filters: Array<{
    column: string
    operator: string
    value: any
  }> = []
  private orderCol: string | null = null
  private orderAsc: boolean = true
  private limitVal: number | null = null

  constructor(table: string) {
    this.table = table
  }

  select(columns: string = "*") {
    return this
  }

  eq(column: string, value: any) {
    this.filters.push({ column, operator: "eq", value })
    return this
  }

  order(column: string, { ascending = true }: { ascending?: boolean } = {}) {
    this.orderCol = column
    this.orderAsc = ascending
    return this
  }

  limit(count: number) {
    this.limitVal = count
    return this
  }

  async then(resolve: (result: QueryResult) => void) {
    if (this.operation === "update")
      return resolve(await this.executeUpdate(this.patch))
    if (this.operation === "delete") return resolve(await this.executeDelete())
    if (isConfigured) {
      try {
        let url = `${SUPABASE_URL}/rest/v1/${this.table}?select=*`
        for (const f of this.filters) {
          url += `&${f.column}=${f.operator}.${encodeURIComponent(f.value)}`
        }
        if (this.orderCol) {
          url += `&order=${this.orderCol}.${this.orderAsc ? "asc" : "desc"}`
        }
        if (this.limitVal) {
          url += `&limit=${this.limitVal}`
        }

        const session = getStoredSession()
        const headers = getSupabaseHeaders(session?.token, "application/json")

        const res = await fetch(url, {
          headers,
          signal: AbortSignal.timeout(10_000),
        })
        if (!res.ok) {
          const err = await res
            .json()
            .catch(() => ({ message: res.statusText }))
          resolve({ data: null, error: err })
          return
        }
        const data = await res.json()
        resolve({ data, error: null })
        return
      } catch (err) {
        resolve({
          data: null,
          error: { message: "Could not load content. Please try again." },
        })
        return
      }
    }

    // Local Storage Mock fallback
    let items = getLocalTable<any>(this.table)
    for (const f of this.filters) {
      items = items.filter((item) => String(item[f.column]) === String(f.value))
    }
    if (this.orderCol) {
      const col = this.orderCol
      const asc = this.orderAsc
      items.sort((a, b) => {
        if (a[col] < b[col]) return asc ? -1 : 1
        if (a[col] > b[col]) return asc ? 1 : -1
        return 0
      })
    }
    if (this.limitVal) {
      items = items.slice(0, this.limitVal)
    }
    resolve({ data: items, error: null })
  }

  async insert(recordOrRecords: any | any[]) {
    const isArray = Array.isArray(recordOrRecords)
    const records = isArray ? recordOrRecords : [recordOrRecords]

    if (isConfigured) {
      try {
        const session = getStoredSession()
        const res = await fetch(`${SUPABASE_URL}/rest/v1/${this.table}`, {
          method: "POST",
          headers: {
            ...getSupabaseHeaders(session?.token, "application/json"),
            Prefer: "return=representation",
          },
          body: JSON.stringify(recordOrRecords),
        })
        if (!res.ok) {
          const err = await res
            .json()
            .catch(() => ({ message: res.statusText }))
          return { data: null, error: err }
        }
        const data = await res.json()
        return { data: isArray ? data : data[0], error: null }
      } catch (e) {
        return {
          data: null,
          error: { message: "Could not save the record. Please try again." },
        }
      }
    }

    // Local fallback
    const items = getLocalTable<any>(this.table)
    const stamped = records.map((r: any) => ({
      id: r.id || "loc_" + Math.random().toString(36).slice(2, 11),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...r,
    }))
    setLocalTable(this.table, [...items, ...stamped])
    return { data: isArray ? stamped : stamped[0], error: null }
  }

  update(patch: any) {
    this.operation = "update"
    this.patch = patch
    return this
  }

  delete() {
    this.operation = "delete"
    return this
  }

  private async executeUpdate(patch: any) {
    const filters = this.filters
    if (!filters.length)
      return {
        data: null,
        error: { message: "A record filter is required for updates." },
      }
    if (isConfigured) {
      try {
        let url = `${SUPABASE_URL}/rest/v1/${this.table}?`
        for (const f of filters) {
          url += `&${f.column}=${f.operator}.${encodeURIComponent(f.value)}`
        }
        const session = getStoredSession()
        const res = await fetch(url, {
          method: "PATCH",
          headers: {
            ...getSupabaseHeaders(session?.token, "application/json"),
            Prefer: "return=representation",
          },
          body: JSON.stringify(patch),
        })
        if (!res.ok) {
          const err = await res
            .json()
            .catch(() => ({ message: res.statusText }))
          return { data: null, error: err }
        }
        const data = await res.json()
        return { data, error: null }
      } catch (e) {
        return {
          data: null,
          error: { message: "Could not save changes. Please try again." },
        }
      }
    }

    // Local fallback
    let items = getLocalTable<any>(this.table)
    items = items.map((item) => {
      const match = filters.every(
        (f) => String(item[f.column]) === String(f.value),
      )
      if (match) {
        return { ...item, ...patch, updated_at: new Date().toISOString() }
      }
      return item
    })
    setLocalTable(this.table, items)
    return { data: items, error: null }
  }

  private async executeDelete() {
    const filters = this.filters
    if (!filters.length)
      return {
        data: null,
        error: { message: "A record filter is required for deletion." },
      }
    if (isConfigured) {
      try {
        let url = `${SUPABASE_URL}/rest/v1/${this.table}?`
        for (const f of filters) {
          url += `&${f.column}=${f.operator}.${encodeURIComponent(f.value)}`
        }
        const session = getStoredSession()
        const res = await fetch(url, {
          method: "DELETE",
          headers: getSupabaseHeaders(session?.token, "application/json"),
        })
        if (!res.ok) {
          const err = await res
            .json()
            .catch(() => ({ message: res.statusText }))
          return { data: null, error: err }
        }
        return { data: true, error: null }
      } catch (e) {
        return {
          data: null,
          error: { message: "Could not delete the record. Please try again." },
        }
      }
    }

    // Local fallback
    let items = getLocalTable<any>(this.table)
    items = items.filter(
      (item) =>
        !filters.every((f) => String(item[f.column]) === String(f.value)),
    )
    setLocalTable(this.table, items)
    return { data: true, error: null }
  }
}

export const supabase = {
  from(table: string) {
    return new QueryBuilder(table)
  },

  auth: {
    async signInWithPassword({
      email,
      password,
    }: {
      email: string
      password?: string
    }) {
      if (isConfigured) {
        try {
          const res = await fetch(
            `${SUPABASE_URL}/auth/v1/token?grant_type=password`,
            {
              method: "POST",
              headers: {
                apikey: SUPABASE_ANON_KEY,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ email, password }),
            },
          )
          const data = await res.json()
          if (!res.ok) {
            return { data: null, error: data }
          }
          setStoredSession(data.access_token, data.user)
          return { data: { user: data.user, session: data }, error: null }
        } catch (e) {
          return {
            data: null,
            error: {
              message: "Could not connect to sign in. Please try again.",
            },
          }
        }
      }

      // Offline / Local admin preview mode
      if (import.meta.env.DEV && password && password.length >= 4) {
        const mockUser = {
          id: "admin-usr-01",
          email: email || "admin@avancelawpartners.info",
          role: "authenticated",
        }
        setStoredSession("local-jwt-token-preview", mockUser)
        return {
          data: { user: mockUser, session: { access_token: "mock-token" } },
          error: null,
        }
      }

      return {
        data: null,
        error: {
          message:
            "Invalid credentials. Password must be at least 4 characters.",
        },
      }
    },

    async signOut() {
      if (isConfigured) {
        const session = getStoredSession()
        if (session?.token) {
          fetch(`${SUPABASE_URL}/auth/v1/logout`, {
            method: "POST",
            headers: getSupabaseHeaders(session.token),
          }).catch(() => {})
        }
      }
      setStoredSession(null, null)
      return { error: null }
    },

    getSession() {
      const stored = getStoredSession()
      if (stored) {
        return { data: { session: stored }, error: null }
      }
      return { data: { session: null }, error: null }
    },

    onAuthStateChange(callback: (event: string, session: any) => void) {
      authListeners.push(callback)
      const current = getStoredSession()
      if (current) callback("INITIAL_SESSION", current)
      return {
        data: {
          subscription: {
            unsubscribe: () => {
              const idx = authListeners.indexOf(callback)
              if (idx >= 0) authListeners.splice(idx, 1)
            },
          },
        },
      }
    },
  },

  storage: {
    from(bucket: string) {
      return {
        async upload(path: string, file: File) {
          if (isConfigured) {
            try {
              const session = getStoredSession()
              const res = await fetch(
                `${SUPABASE_URL}/storage/v1/object/${bucket}/${path}`,
                {
                  method: "POST",
                  headers: getSupabaseHeaders(session?.token, file.type),
                  body: file,
                },
              )
              if (res.ok) {
                return { data: { path }, error: null }
              }
              return {
                data: null,
                error: {
                  message: "Could not upload this image. Please try again.",
                },
              }
            } catch (e) {
              return {
                data: null,
                error: {
                  message:
                    "Could not connect to image storage. Please try again.",
                },
              }
            }
          }

          // Local fallback: convert to base64 data URL
          return new Promise<{
            data: any
            error: any
          }>((resolve) => {
            const reader = new FileReader()
            reader.onload = () => {
              const dataUrl = reader.result as string
              // store in local media table
              const mediaList = getLocalTable<any>("media")
              mediaList.push({
                id: "med_" + Math.random().toString(36).slice(2, 9),
                url: dataUrl,
                file_name: file.name,
                file_size: file.size,
                mime_type: file.type,
                uploaded_at: new Date().toISOString(),
              })
              setLocalTable("media", mediaList)
              resolve({ data: { path, publicUrl: dataUrl }, error: null })
            }
            reader.onerror = () =>
              resolve({ data: null, error: { message: "File read failed" } })
            reader.readAsDataURL(file)
          })
        },

        getPublicUrl(path: string) {
          if (isConfigured) {
            return {
              data: {
                publicUrl: `${SUPABASE_URL}/storage/v1/object/public/${bucket}/${path}`,
              },
            }
          }
          return { data: { publicUrl: path } }
        },

        async list() {
          if (isConfigured) {
            try {
              const session = getStoredSession()
              const res = await fetch(
                `${SUPABASE_URL}/storage/v1/object/list/${bucket}`,
                {
                  method: "POST",
                  headers: getSupabaseHeaders(
                    session?.token,
                    "application/json",
                  ),
                  body: JSON.stringify({ prefix: "" }),
                },
              )
              if (res.ok) {
                const data = await res.json()
                return { data, error: null }
              }
            } catch (e) {
              // fallback
            }
          }
          const media = getLocalTable<any>("media")
          return { data: media, error: null }
        },
      }
    },
  },
}
