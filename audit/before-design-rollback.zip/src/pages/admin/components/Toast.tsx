import { AlertTriangle, Check, X } from "lucide-react"

export default function Toast({
  message,
  type = message.startsWith("Could not") ? "error" : "success",
  onClose,
}: {
  message: string
  type?: "success" | "error"
  onClose: () => void
}) {
  return (
    <div
      role={type === "error" ? "alert" : "status"}
      className="fixed bottom-4 left-4 right-4 z-50 flex items-center gap-3 border border-line-dark bg-obsidian px-4 py-3 text-sm text-ivory sm:left-auto sm:max-w-md"
    >
      <span className={type === "success" ? "text-gold" : "text-red-400"}>
        {type === "success" ? (
          <Check aria-hidden size={16} />
        ) : (
          <AlertTriangle aria-hidden size={16} />
        )}
      </span>
      <span>{message}</span>
      <button
        type="button"
        aria-label="Dismiss notification"
        onClick={onClose}
        className="ml-auto inline-flex h-11 w-11 shrink-0 items-center justify-center text-ivory/75 hover:text-ivory"
      >
        <X aria-hidden size={15} />
      </button>
    </div>
  )
}
