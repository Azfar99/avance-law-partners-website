import { useEffect, useId, useRef, useState } from "react"

export default function ConfirmDialog({
  title,
  message,
  confirmLabel = "Delete",
  onConfirm,
  onCancel,
}: {
  title: string
  message: string
  confirmLabel?: string
  onConfirm: () => void | Promise<void>
  onCancel: () => void
}) {
  const dialog = useRef<HTMLDialogElement>(null)
  const [busy, setBusy] = useState(false)
  const heading = useId()
  const description = useId()
  useEffect(() => {
    const element = dialog.current
    if (!element) return
    const previous = document.body.style.overflow
    document.body.style.overflow = "hidden"
    element.showModal()
    return () => {
      element.close()
      document.body.style.overflow = previous
    }
  }, [])
  return (
    <dialog
      ref={dialog}
      aria-labelledby={heading}
      aria-describedby={description}
      onCancel={(event) => {
        event.preventDefault()
        if (!busy) onCancel()
      }}
      className="fixed inset-0 m-auto max-h-[90dvh] w-[calc(100%_-_2rem)] max-w-md overflow-auto border border-line-light bg-ivory p-6 text-charcoal backdrop:bg-black/70"
    >
      <h2 id={heading} className="font-serif text-2xl text-obsidian">
        {title}
      </h2>
      <p id={description} className="mt-3 text-sm leading-relaxed">
        {message}
      </p>
      <div className="mt-6 flex flex-wrap justify-end gap-3">
        <button
          autoFocus
          type="button"
          disabled={busy}
          onClick={onCancel}
          className="min-h-11 border border-line-light px-4 py-2 text-sm font-semibold hover:bg-stone disabled:opacity-60"
        >
          Cancel
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={async () => {
            setBusy(true)
            try {
              await onConfirm()
            } finally {
              setBusy(false)
            }
          }}
          className="min-h-11 bg-red-800 px-4 py-2 text-sm font-semibold text-ivory hover:bg-red-900 disabled:opacity-60"
        >
          {busy ? "Please wait..." : confirmLabel}
        </button>
      </div>
    </dialog>
  )
}
