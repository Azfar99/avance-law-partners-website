import { approach, firmIntro } from "../lib/content"
import { useServices, useSiteSettings } from "../lib/hooks"
import { Container, Eyebrow, InlineLink, Reveal } from "../components/ui"
import { SectionHead } from "../components/parts"
import { useHeroTone } from "../lib/chrome"
import SEOHead from "../components/SEOHead"

const ABOUT_IMG =
  "https://images.unsplash.com/photo-1641987273839-74f6c6f1b4b3?w=1000&h=1250&fit=crop&auto=format&q=80"

const ABOUT_IMG_SRCSET = [480, 768, 1120]
  .map((width) => `${ABOUT_IMG.replace(/w=\d+/, `w=${width}`)} ${width}w`)
  .join(", ")

export default function About() {
  useHeroTone("light")
  const { settings } = useSiteSettings()
  const { services } = useServices()
  const established = Number(settings.established)
  const yearsPracticing =
    Number.isFinite(established) &&
    established >= 1800 &&
    established <= new Date().getFullYear()
      ? new Date().getFullYear() - established
      : null

  return (
    <>
      <SEOHead
        title="About Us & Practice History"
        description="Established in 1998, Avance Law Partners combines sound legal expertise with practical, commercially focused advice in Dhaka, Bangladesh."
        canonicalPath="/about"
      />
      {/* Quieter ivory opening, with a large typographic "1998" watermark */}
      <section className="relative overflow-hidden bg-ivory">
        <span
          aria-hidden
          className="pointer-events-none absolute -right-6 top-24 select-none font-serif text-[clamp(9rem,26vw,24rem)] leading-none text-obsidian/[0.035] lg:top-28"
        >
          1998
        </span>
        <Container className="relative pb-12 pt-28 lg:pb-16 lg:pt-36">
          <Eyebrow>About the firm</Eyebrow>
          <h1 className="mt-8 max-w-4xl text-obsidian display-hero">
            A practice built on clear advice.
          </h1>
          <div className="mt-8 flex flex-wrap items-stretch gap-x-14 gap-y-8 border-t border-line-light pt-10">
            {[
              {
                k:
                  yearsPracticing === null
                    ? "1998"
                    : yearsPracticing.toString(),
                v:
                  yearsPracticing === null
                    ? "Established"
                    : "Years of practice",
              },
              { k: services.length.toString(), v: "Practice areas" },
              { k: "Dhaka", v: "Bangladesh" },
            ].map((stat) => (
              <div key={stat.v} className="min-w-[120px]">
                <p className="font-serif text-[clamp(2rem,4vw,3.25rem)] leading-none text-copper">
                  {stat.k}
                </p>
                <p className="mt-2 text-[13px] uppercase tracking-[0.16em] text-ink-60">
                  {stat.v}
                </p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="bg-ivory">
        <Container className="pb-14 lg:pb-20">
          <div className="grid gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-20">
            <Reveal>
              <p className="text-[20px] leading-relaxed text-charcoal">
                {firmIntro.primary}
              </p>
              <p className="mt-6 text-[18px] leading-relaxed text-charcoal/80">
                {firmIntro.secondary}
              </p>
              <p className="mt-6 text-[18px] leading-relaxed text-charcoal/80">
                {firmIntro.tertiary}
              </p>
            </Reveal>
            <Reveal style={{ animationDelay: "80ms" }}>
              <div className="overflow-hidden rounded-[6px] bg-charcoal">
                <img
                  src={ABOUT_IMG}
                  srcSet={ABOUT_IMG_SRCSET}
                  sizes="(min-width: 1024px) 500px, calc(100vw - 40px)"
                  alt="Daylight across stone and timber in an illustrative interior"
                  loading="lazy"
                  decoding="async"
                  className="aspect-[4/3] h-full w-full object-cover"
                />
              </div>
              <p className="mt-3 text-[12px] italic text-ink-60">
                Illustrative photograph. This is not the firm's office.
              </p>
            </Reveal>
          </div>
        </Container>
      </section>

      {/* Approach statement */}
      <section className="border-y border-line-light bg-stone">
        <Container className="py-14 lg:py-20">
          <SectionHead
            eyebrow="Our approach"
            title="Responsive. Practical. Commercially sound."
          >
            {approach.statement}
          </SectionHead>
          <div className="mt-8 grid gap-8 md:grid-cols-3">
            {approach.principles.map((p, i) => (
              <Reveal key={p.title} style={{ animationDelay: `${i * 60}ms` }}>
                <div className="border-t border-charcoal/20 pt-6">
                  <h3 className="font-serif text-[24px] text-obsidian">
                    {p.title}
                  </h3>
                  <p className="mt-3 text-[16px] leading-relaxed text-charcoal/80">
                    {p.body}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
          <div className="mt-8">
            <InlineLink to="/approach">More on how we work</InlineLink>
          </div>
        </Container>
      </section>

      {/* Lawyers intro */}
      <section className="bg-obsidian text-ivory">
        <Container className="py-14 lg:py-20">
          <div className="grid items-center gap-10 lg:grid-cols-[1.3fr_1fr]">
            <div>
              <Eyebrow tone="light">Our lawyers</Eyebrow>
              <h2 className="display-section mt-4 text-ivory">
                Experienced counsel, directly involved.
              </h2>
              <p className="mt-5 max-w-lg text-[18px] leading-relaxed text-ivory/75">
                Our lawyers work closely with clients from first conversation to
                resolution. Meet the people behind the practice.
              </p>
            </div>
            <div className="lg:justify-self-end">
              <InlineLink to="/lawyers" tone="light">
                Meet our lawyers
              </InlineLink>
            </div>
          </div>
          <p className="mt-10 border-t border-line-dark pt-8 text-[15px] text-ivory/50">
            {settings.firm_name} · {settings.location}
          </p>
        </Container>
      </section>
    </>
  )
}
