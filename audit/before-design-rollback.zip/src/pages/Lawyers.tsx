import { useLawyers } from "../lib/hooks"
import { Container, Eyebrow, InlineLink, Reveal } from "../components/ui"
import { Breadcrumb, LawyerCard } from "../components/parts"
import { useHeroTone } from "../lib/chrome"
import SEOHead from "../components/SEOHead"

export default function Lawyers() {
  useHeroTone("light")
  const { lawyers, loading } = useLawyers()
  return (
    <section className="bg-ivory">
      <SEOHead
        title="Our Lawyers & Legal Counsel"
        description="Meet the advocates and legal counsel at Avance Law Partners in Dhaka, Bangladesh."
        canonicalPath="/lawyers"
      />
      <Container className="pb-16 pt-28 lg:pb-20 lg:pt-36">
        <Breadcrumb
          trail={[{ label: "Home", to: "/" }, { label: "Lawyers" }]}
        />
        <div className="mt-7 border-t border-obsidian pt-6">
          <Eyebrow>Our lawyers</Eyebrow>
          <h1 className="display-hero mt-4 max-w-3xl">
            The people behind the practice.
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-60">
            Get to know our lawyers, their experience and the areas they advise
            on.
          </p>
        </div>
        {loading && lawyers.length === 0 && (
          <p role="status" className="mt-8">
            Loading profiles...
          </p>
        )}
        {!loading && lawyers.length === 0 && (
          <div className="mt-8 border-t border-line-light pt-6">
            <p className="mb-4">
              Please contact the firm for information about our lawyers.
            </p>
            <InlineLink to="/contact">Contact the firm</InlineLink>
          </div>
        )}
        <div className="mt-9 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {lawyers.map((lawyer) => (
            <Reveal key={lawyer.slug}>
              <LawyerCard lawyer={lawyer} />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  )
}
