import { ArrowUpRight } from "lucide-react"
import { approach } from "../lib/content"
import {
  useLawyers,
  usePageContent,
  useServices,
  useSiteSettings,
} from "../lib/hooks"
import { useHeroTone } from "../lib/chrome"
import {
  AppLink,
  ButtonLink,
  Container,
  Eyebrow,
  InlineLink,
  Reveal,
} from "../components/ui"
import { LawyerCard } from "../components/parts"
import WindowOfClarity from "../components/WindowOfClarity"
import SEOHead from "../components/SEOHead"

function Hero() {
  const { settings } = useSiteSettings()
  const { content } = usePageContent("home")
  return (
    <section className="bg-obsidian text-ivory">
      <Container className="pb-0 pt-28 sm:pt-32 lg:pt-36">
        <div className="grid items-center gap-9 pb-10 lg:grid-cols-[1.05fr_1fr] lg:gap-14 lg:pb-14">
          <div className="min-w-0 py-2 lg:py-6">
            <Eyebrow tone="light">
              {settings.location} · Established {settings.established}
            </Eyebrow>
            <h1 className="display-hero mt-5 max-w-2xl text-ivory">
              {content.hero_title || "Clear advice. Considered action."}
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-ivory-dim sm:text-lg">
              {content.hero_subtitle ||
                "Legal advice and representation for businesses, institutions and individuals in Bangladesh."}
            </p>
            <div className="mt-7 flex flex-col gap-3 min-[400px]:flex-row min-[400px]:flex-wrap">
              <ButtonLink to="/contact" withArrow>
                Speak with counsel
              </ButtonLink>
              <ButtonLink to="/services" variant="outline-light">
                Our practice areas
              </ButtonLink>
            </div>
            <p className="mt-7 border-t border-ivory/20 pt-4 text-sm text-ivory/70">
              Corporate & commercial · Disputes · Regulatory
            </p>
          </div>
          <figure className="min-w-0">
            <WindowOfClarity
              priority
              className="aspect-[16/10] w-full lg:aspect-[6/5]"
            />
            <figcaption className="mt-3 flex flex-wrap justify-between gap-2 text-xs text-ivory/65">
              <span>Built on research. Guided by judgment.</span>
              <span>Illustrative library photograph</span>
            </figcaption>
          </figure>
        </div>
      </Container>
    </section>
  )
}

function Introduction() {
  const { content } = usePageContent("home")
  return (
    <section className="border-b border-line-light bg-ivory">
      <Container className="section-space grid gap-8 lg:grid-cols-[.8fr_1.2fr] lg:gap-20">
        <Reveal>
          <Eyebrow>About the firm</Eyebrow>
          <h2 className="display-section mt-4 max-w-md">
            {content.intro_heading ||
              "Legal counsel with your priorities in view."}
          </h2>
        </Reveal>
        <Reveal>
          <p className="max-w-2xl text-lg leading-relaxed text-charcoal">
            {content.intro_primary ||
              "We help clients understand their position, weigh the risks and decide what to do next."}
          </p>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-ink-60">
            {content.intro_secondary ||
              "Our work spans company and commercial matters, contracts, regulatory issues and dispute resolution."}
          </p>
          <p className="mt-5 border-t border-line-light pt-4 text-sm text-ink-60">
            For businesses, institutions and individuals.
          </p>
          <div className="mt-5">
            <InlineLink to="/about">Learn about the firm</InlineLink>
          </div>
        </Reveal>
      </Container>
    </section>
  )
}

function ServicesPreview() {
  const { services, loading } = useServices()
  return (
    <section className="bg-stone">
      <Container className="section-space">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <Eyebrow>Practice areas</Eyebrow>
            <h2 className="display-section mt-4">How we can help.</h2>
          </div>
          <InlineLink to="/services">View all practice areas</InlineLink>
        </div>
        {loading && services.length === 0 && (
          <p role="status" className="mt-8 text-ink-60">
            Loading practice areas...
          </p>
        )}
        {!loading && services.length === 0 && (
          <p className="mt-8 text-ink-60">
            Please contact the firm to discuss your matter.
          </p>
        )}
        <ol className="mt-8 grid gap-x-12 md:grid-cols-2">
          {services.map((service, index) => (
            <Reveal
              key={service.slug}
              as="li"
              className="border-t border-line-light"
            >
              <AppLink
                to={`/services/${service.slug}`}
                className="practice-link group grid min-h-32 grid-cols-[24px_1fr_20px] gap-3 py-5 sm:gap-4"
              >
                <span className="pt-1 text-xs font-semibold text-copper">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="min-w-0">
                  <h3 className="font-serif text-2xl leading-tight text-obsidian group-hover:text-copper">
                    {service.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-60">
                    {service.summary}
                  </p>
                </div>
                <ArrowUpRight
                  aria-hidden
                  size={19}
                  className="mt-1 text-copper"
                />
              </AppLink>
            </Reveal>
          ))}
        </ol>
      </Container>
    </section>
  )
}

function LawyersPreview() {
  const { lawyers, loading } = useLawyers()
  if (!loading && lawyers.length === 0) return null
  return (
    <section className="border-t border-line-light bg-ivory">
      <Container className="section-space">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <Eyebrow>Our lawyers</Eyebrow>
            <h2 className="display-section mt-4">
              The people you will work with.
            </h2>
          </div>
          <InlineLink to="/lawyers">Meet our lawyers</InlineLink>
        </div>
        <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {lawyers.slice(0, 3).map((lawyer) => (
            <Reveal key={lawyer.slug}>
              <LawyerCard lawyer={lawyer} />
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  )
}

function Approach() {
  return (
    <section className="bg-obsidian text-ivory">
      <Container className="section-space">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <Eyebrow tone="light">How we work</Eyebrow>
            <h2 className="display-section mt-4">A clear way forward.</h2>
          </div>
          <InlineLink to="/approach" tone="light">
            Our approach
          </InlineLink>
        </div>
        <div className="mt-8 grid gap-7 md:grid-cols-3 md:gap-10">
          {approach.principles.map((principle, index) => (
            <Reveal
              key={principle.title}
              className="border-t border-ivory/25 pt-5"
            >
              <span className="text-xs text-gold">0{index + 1}</span>
              <h3 className="mt-3 font-serif text-2xl">{principle.title}</h3>
              <p className="mt-3 text-base leading-relaxed text-ivory/75">
                {principle.body}
              </p>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  )
}

export default function Home() {
  useHeroTone("dark")
  return (
    <>
      <SEOHead
        title="Avance Law Partners | Legal Counsel in Dhaka"
        description="Corporate, commercial, regulatory and dispute resolution legal counsel in Dhaka, Bangladesh."
        canonicalPath="/"
      />
      <Hero />
      <Introduction />
      <ServicesPreview />
      <LawyersPreview />
      <Approach />
    </>
  )
}
