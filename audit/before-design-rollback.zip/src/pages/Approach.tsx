import { approach } from "../lib/content"
import { ButtonLink, Container, Eyebrow, Reveal } from "../components/ui"
import { Breadcrumb } from "../components/parts"
import SEOHead from "../components/SEOHead"
import { usePageContent } from "../lib/hooks"

export default function Approach() {
  const { content } = usePageContent("home")

  return (
    <>
      <SEOHead
        title="Our Approach"
        description="How Avance Law Partners approaches your legal matter, from the first discussion to the next steps."
        canonicalPath="/approach"
      />
      {/* Full-bleed typographic manifesto. the three principles ARE the hero */}
      <section className="relative overflow-hidden bg-obsidian text-ivory">
        <span
          aria-hidden
          className="pointer-events-none absolute inset-y-0 left-1/2 hidden w-px bg-line-dark lg:block"
        />
        <Container className="pb-20 pt-32 lg:pb-28 lg:pt-40">
          <div className="[&_a]:text-ivory/55 [&_a:hover]:text-ivory [&_[aria-current]]:text-ivory/90 [&_span]:text-ivory/25">
            <Breadcrumb
              trail={[{ label: "Home", to: "/" }, { label: "Our approach" }]}
            />
          </div>
          <p className="eyebrow mt-10 text-gold">How we work</p>
          <h1 className="mt-6 font-serif text-[clamp(2.4rem,6vw,4.5rem)] font-medium leading-[1.08] tracking-[-0.02em]">
            <span className="block text-ivory">Responsive.</span>
            <span className="block text-gold">Practical.</span>
            <span className="block text-ivory/80">
              Commercially<span className="text-ivory"> sound.</span>
            </span>
          </h1>
          <p className="mt-8 max-w-xl text-[19px] leading-relaxed text-ivory/70 lg:ml-auto lg:text-right">
            {content.approach_statement || approach.statement}
          </p>
        </Container>
      </section>

      {/* Principles share one reading order at every viewport width. */}
      <section className="bg-ivory">
        <Container className="py-14 lg:py-20">
          {approach.principles.map((p, i) => (
            <Reveal key={p.title}>
              <div className="grid items-start gap-4 border-t border-line-light py-8 lg:grid-cols-[48px_1fr_1.4fr] lg:gap-8 lg:py-10">
                <span aria-hidden className="text-sm font-semibold text-copper">
                  0{i + 1}
                </span>
                <h2 className="display-section text-obsidian">{p.title}</h2>
                <p className="max-w-xl text-lg leading-relaxed text-charcoal">
                  {p.body}
                </p>
              </div>
            </Reveal>
          ))}
        </Container>
      </section>

      {/* Two-tone split CTA */}
      <section className="grid md:grid-cols-2">
        <div className="bg-obsidian px-6 py-10 text-ivory sm:px-10 lg:px-16 lg:py-14">
          <Eyebrow tone="light">Map it to your matter</Eyebrow>
          <h2 className="display-section mt-4 max-w-sm text-ivory">
            See which practice area fits.
          </h2>
          <div className="mt-8">
            <ButtonLink
              to="/services"
              variant="outline-light"
              size="lg"
              withArrow
            >
              View services
            </ButtonLink>
          </div>
        </div>
        <div className="bg-gold px-6 py-10 text-obsidian sm:px-10 lg:px-16 lg:py-14">
          <p className="eyebrow text-obsidian/70">Start a conversation</p>
          <h2 className="display-section mt-4 max-w-sm text-obsidian">
            Tell us what you are facing.
          </h2>
          <div className="mt-8">
            <ButtonLink
              to="/contact"
              variant="outline-dark"
              size="lg"
              withArrow
              className="border-obsidian/40 text-obsidian hover:border-obsidian hover:bg-obsidian/5"
            >
              Make an enquiry
            </ButtonLink>
          </div>
        </div>
      </section>
    </>
  )
}
