import { useEffect, useMemo, useRef, useState, type FormEvent } from "react"
import {
  lawyers as defaultLawyers,
  services as defaultServices,
} from "../lib/content"
import { useSiteSettings, useServices } from "../lib/hooks"
import { AppLink, Button, Container, InlineLink } from "../components/ui"
import { useRouter } from "../lib/router"
import { useHeroTone } from "../lib/chrome"
import SEOHead from "../components/SEOHead"
import { invokeEdgeFunction, isConfigured } from "../lib/supabase"
import {
  normalizeEnquiry,
  validateEnquiry,
  type EnquiryErrors as Errors,
} from "../lib/contactValidation"

type Status = "idle" | "sent"
const primaryContact = defaultLawyers.find(
  (lawyer) => lawyer.slug === "lawyer-one",
)
const contactPhone = primaryContact?.phone ?? "+88 01628 781 222"
const contactEmail = primaryContact?.email ?? "isratarni1422@gmail.com"

const fieldBase =
  "w-full border-0 border-b bg-transparent px-0 py-3 text-[16px] text-charcoal transition-colors placeholder:text-ink-60/60 focus:outline-none focus-visible:border-gold focus-visible:ring-0"

function Label({
  htmlFor,
  children,
  optional,
}: {
  htmlFor: string
  children: string
  optional?: boolean
}) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-2 block text-[14px] font-semibold text-charcoal"
    >
      {children}
      {!optional ? (
        <span className="text-copper"> *</span>
      ) : (
        <span className="ml-1 font-normal text-ink-60">(optional)</span>
      )}
    </label>
  )
}

export default function Contact() {
  useHeroTone("dark")
  const { settings } = useSiteSettings()
  const { services } = useServices()
  const { query } = useRouter()
  const preselected = query.get("matter") ?? ""

  const [status, setStatus] = useState<Status>("idle")
  const [isSending, setIsSending] = useState(false)
  const [submitError, setSubmitError] = useState("")
  const sending = useRef(false)
  const confirmation = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (status === "sent") confirmation.current?.focus()
  }, [status])
  const [errors, setErrors] = useState<Errors>({})
  const [values, setValues] = useState({
    name: "",
    email: "",
    phone: "",
    subject: preselected,
    message: "",
  })
  const subjectOptions = useMemo(() => {
    const list = services.length > 0 ? services : defaultServices
    return list.map((s) => s.title)
  }, [services])

  function set<K extends keyof typeof values>(key: K, v: string) {
    setValues((prev) => ({ ...prev, [key]: v }))
    if (errors[(key as keyof Errors)]) {
      setErrors((prev) => ({ ...prev, [key]: undefined }))
    }
  }

  function validate(): Errors {
    return validateEnquiry(values)
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (sending.current) return
    const next = validate()
    setErrors(next)
    if (Object.keys(next).length > 0) {
      // Move focus to the first invalid field.
      const first = document.getElementById(Object.keys(next)[0])
      first?.focus({ preventScroll: true })
      first?.scrollIntoView({ behavior: "instant", block: "center" })
      return
    }

    sending.current = true
    setIsSending(true)
    setSubmitError("")
    try {
      const result = await invokeEdgeFunction<{ ok?: boolean }>(
        "send-contact-enquiry",
        normalizeEnquiry(values),
      )
      if (result?.ok !== true)
        throw new Error(
          "We could not confirm delivery. Please contact the firm by phone or email.",
        )
      setStatus("sent")
    } catch (error) {
      setSubmitError(
        error instanceof Error
          ? error.message
          : "We could not send your enquiry right now. Please try again.",
      )
    } finally {
      sending.current = false
      setIsSending(false)
    }
  }

  return (
    <>
      <SEOHead
        title="Contact & Chamber Consultations"
        description="Contact Avance Law Partners in Hatirjheel, Dhaka. Start with a consultation regarding your corporate or legal matter."
        canonicalPath="/contact"
      />
      <section className="relative overflow-hidden bg-obsidian text-ivory arch-grid">
        <Container className="relative pb-10 pt-28 sm:pb-12 sm:pt-32 lg:pb-14 lg:pt-40">
          <div className="grid items-end gap-10 lg:grid-cols-[1.25fr_.75fr]">
            <div>
              <p className="eyebrow text-gold">Contact · Dhaka</p>
              <h1 className="display-hero mt-5 max-w-3xl text-ivory">
                Start with a conversation.
              </h1>
            </div>
            <p className="max-w-md border-l border-gold/50 pl-6 text-[18px] leading-relaxed text-ivory/75 lg:justify-self-end">
              Tell us a little about the matter and we will point you to the
              right counsel and a sensible next step.
            </p>
          </div>
          <div className="mt-8 grid max-w-3xl gap-3 sm:grid-cols-2">
            <a
              href={`tel:${contactPhone.replace(/[^+\d]/g, "")}`}
              className="group flex min-h-[82px] flex-col justify-center border border-gold/35 bg-ivory/[0.04] px-5 py-4 transition-colors hover:border-gold/75 hover:bg-ivory/[0.08] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
            >
              <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-gold">
                Call Israt
              </span>
              <span className="mt-1 text-[15px] font-medium text-ivory group-hover:text-gold sm:text-[16px]">
                {contactPhone}
              </span>
              <span className="mt-1 text-[11px] text-ivory/55">
                Managing Partner
              </span>
            </a>
            <a
              href={`mailto:${contactEmail}`}
              className="group flex min-h-[82px] min-w-0 flex-col justify-center border border-gold/35 bg-ivory/[0.04] px-5 py-4 transition-colors hover:border-gold/75 hover:bg-ivory/[0.08] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold"
            >
              <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-gold">
                Email Israt
              </span>
              <span className="mt-1 break-all text-[14px] font-medium text-ivory group-hover:text-gold sm:text-[16px] sm:break-normal">
                {contactEmail}
              </span>
              <span className="mt-1 text-[11px] text-ivory/55">
                Managing Partner
              </span>
            </a>
          </div>
        </Container>
      </section>

      <section className="relative bg-ivory paper-grain">
        <Container className="py-10 sm:py-14 lg:py-16">
          <div className="mx-auto max-w-4xl">
            {/* Form */}
            <div className="border-t-2 border-obsidian pt-7">
              <div className="mb-9 flex items-baseline justify-between border-b border-line-light pb-4">
                <p className="eyebrow text-ink-60">Enquiry form</p>
                <span className="font-serif text-[18px] text-copper">01</span>
              </div>
              {status === "sent" ? (
                <div
                  ref={confirmation}
                  tabIndex={-1}
                  role="status"
                  className="border-y border-gold/40 bg-gold/10 p-8"
                >
                  <p className="eyebrow text-copper">Enquiry sent</p>
                  <h2 className="mt-3 font-serif text-[30px] text-obsidian">
                    Thank you for contacting Avance Law Partners.
                  </h2>
                  <p className="mt-3 max-w-md text-[16px] leading-relaxed text-charcoal/80">
                    Your message has been sent successfully. Our team will
                    respond as soon as possible.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setValues({
                        name: "",
                        email: "",
                        phone: "",
                        subject: "",
                        message: "",
                      })
                      setStatus("idle")
                      requestAnimationFrame(() =>
                        document.getElementById("name")?.focus(),
                      )
                    }}
                    className="mt-5 min-h-11 font-semibold underline underline-offset-4"
                  >
                    Send another enquiry
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={onSubmit}
                  noValidate
                  aria-busy={isSending}
                  className="space-y-6"
                >
                  <p
                    id="enquiry-help"
                    className="text-sm leading-relaxed text-ink-60"
                  >
                    Fields marked * are required. Please share a brief outline.
                    Avoid sending confidential documents or sensitive details at
                    this stage.
                  </p>
                  {!isConfigured && (
                    <p
                      role="status"
                      className="border-l-2 border-gold pl-4 text-sm text-ink-60"
                    >
                      The enquiry form is currently unavailable. Please contact
                      the firm by phone or email.
                    </p>
                  )}
                  <fieldset
                    disabled={isSending}
                    className="space-y-6 disabled:opacity-70"
                  >
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <Label htmlFor="name">Name</Label>
                        <input
                          id="name"
                          name="name"
                          autoComplete="name"
                          required
                          maxLength={120}
                          value={values.name}
                          onChange={(e) => set("name", e.target.value)}
                          aria-invalid={!!errors.name}
                          aria-describedby={
                            errors.name ? "name-err" : undefined
                          }
                          className={`${fieldBase} ${
                            errors.name ? "border-red-800" : "border-line-light"
                          }`}
                        />
                        {errors.name && (
                          <p
                            id="name-err"
                            className="mt-1.5 text-[13px] text-red-900"
                          >
                            {errors.name}
                          </p>
                        )}
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <input
                          id="email"
                          name="email"
                          type="email"
                          autoComplete="email"
                          required
                          maxLength={254}
                          value={values.email}
                          onChange={(e) => set("email", e.target.value)}
                          aria-invalid={!!errors.email}
                          aria-describedby={
                            errors.email ? "email-err" : undefined
                          }
                          className={`${fieldBase} ${
                            errors.email
                              ? "border-red-800"
                              : "border-line-light"
                          }`}
                        />
                        {errors.email && (
                          <p
                            id="email-err"
                            className="mt-1.5 text-[13px] text-red-900"
                          >
                            {errors.email}
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="phone" optional>
                        Phone
                      </Label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        autoComplete="tel"
                        maxLength={60}
                        aria-invalid={!!errors.phone}
                        aria-describedby={
                          errors.phone ? "phone-err" : undefined
                        }
                        value={values.phone}
                        onChange={(e) => set("phone", e.target.value)}
                        className={`${fieldBase} border-line-light`}
                      />
                      {errors.phone && (
                        <p
                          id="phone-err"
                          className="mt-1.5 text-sm text-red-900"
                        >
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="subject">Subject / Legal matter</Label>
                      <select
                        id="subject"
                        name="subject"
                        required
                        value={values.subject}
                        onChange={(e) => set("subject", e.target.value)}
                        aria-invalid={!!errors.subject}
                        aria-describedby={
                          errors.subject ? "subject-err" : undefined
                        }
                        className={`${fieldBase} ${
                          errors.subject
                            ? "border-red-800"
                            : "border-line-light"
                        } ${
                          values.subject ? "text-charcoal" : "text-ink-60/70"
                        }`}
                      >
                        <option value="">Select a legal matter…</option>
                        {preselected &&
                          !subjectOptions.includes(preselected) && (
                            <option value={preselected}>
                              Selected matter: {preselected.slice(0, 160)}
                            </option>
                          )}
                        {subjectOptions.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                        <option value="Other / general enquiry">
                          Other / general enquiry
                        </option>
                      </select>
                      {errors.subject && (
                        <p
                          id="subject-err"
                          className="mt-1.5 text-[13px] text-red-900"
                        >
                          {errors.subject}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="message">Message</Label>
                      <textarea
                        id="message"
                        name="message"
                        rows={5}
                        required
                        maxLength={5000}
                        value={values.message}
                        onChange={(e) => set("message", e.target.value)}
                        aria-invalid={!!errors.message}
                        aria-describedby={
                          errors.message
                            ? "message-err message-count"
                            : "message-count"
                        }
                        className={`${fieldBase} resize-y ${
                          errors.message
                            ? "border-red-800"
                            : "border-line-light"
                        }`}
                      />
                      <p
                        id="message-count"
                        className="mt-2 text-right text-xs text-ink-60"
                      >
                        {values.message.length.toLocaleString()} / 5,000
                      </p>
                      {errors.message && (
                        <p
                          id="message-err"
                          className="mt-1.5 text-[13px] text-red-900"
                        >
                          {errors.message}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                      <Button
                        type="submit"
                        disabled={isSending || !isConfigured}
                        aria-busy={isSending}
                        size="lg"
                        withArrow
                        className="w-full sm:w-auto"
                      >
                        {isSending ? "Sending…" : "Send enquiry"}
                      </Button>
                      <p className="text-[13px] leading-relaxed text-ink-60">
                        Please read our{" "}
                        <AppLink
                          to="/privacy"
                          className="font-semibold text-copper underline underline-offset-4"
                        >
                          Privacy Policy
                        </AppLink>
                        .
                      </p>
                    </div>
                  </fieldset>
                  {submitError && (
                    <p
                      role="alert"
                      className="text-[13px] leading-relaxed text-red-900"
                    >
                      {submitError}{" "}
                      <a
                        href={`mailto:${contactEmail}`}
                        className="underline underline-offset-4"
                      >
                        Email the firm instead
                      </a>
                    </p>
                  )}
                </form>
              )}
            </div>
          </div>
        </Container>
      </section>

      <section className="border-t border-line-light bg-stone">
        <Container className="py-12 sm:py-16">
          <div className="grid gap-5 sm:grid-cols-[.55fr_1.45fr] sm:gap-10">
            <div>
              <p className="eyebrow text-copper">Our office</p>
            </div>
            <div>
              <address className="not-italic text-[16px] leading-relaxed text-charcoal sm:text-[18px]">
                <span className="block">{settings.address_line_1}</span>
                <span className="block">{settings.address_line_2}</span>
                <span className="block">{settings.address_line_3}</span>
              </address>
              {settings.office_hours && (
                <p className="mt-4 text-[13px] leading-relaxed text-ink-60">
                  <span className="font-semibold text-charcoal">
                    Office Hours:
                  </span>{" "}
                  {settings.office_hours}
                </p>
              )}
              <div className="mt-6">
                <InlineLink to="/approach">How we work</InlineLink>
              </div>
            </div>
          </div>
        </Container>
      </section>
    </>
  )
}
