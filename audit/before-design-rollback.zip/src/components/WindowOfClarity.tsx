import { useEffect, useRef, useState } from "react"

const DEFAULT_SOURCE =
  "https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&q=80&w=1200"

// The reveal stays inside the photograph and retains the native cursor.
export function WindowOfClarity({
  className = "",
  src = DEFAULT_SOURCE,
  alt = "A law library with shelves of legal books",
  priority = false,
}: {
  className?: string
  src?: string
  alt?: string
  priority?: boolean
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [failed, setFailed] = useState(false)
  useEffect(() => {
    const element = ref.current
    if (!element || failed) return
    const preference = window.matchMedia(
      "(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
    )
    let frame = 0
    let x = 0
    let y = 0
    const reset = () => {
      cancelAnimationFrame(frame)
      frame = 0
      element.removeAttribute("data-revealing")
    }
    const onMove = (event: PointerEvent) => {
      if (!preference.matches || event.pointerType !== "mouse") return
      const rect = element.getBoundingClientRect()
      x = event.clientX - rect.left
      y = event.clientY - rect.top
      if (frame) return
      frame = requestAnimationFrame(() => {
        element.style.setProperty("--reveal-x", `${x}px`)
        element.style.setProperty("--reveal-y", `${y}px`)
        element.setAttribute("data-revealing", "true")
        frame = 0
      })
    }
    element.addEventListener("pointermove", onMove, { passive: true })
    element.addEventListener("pointerleave", reset)
    element.addEventListener("pointercancel", reset)
    preference.addEventListener("change", reset)
    window.addEventListener("blur", reset)
    return () => {
      reset()
      element.removeEventListener("pointermove", onMove)
      element.removeEventListener("pointerleave", reset)
      element.removeEventListener("pointercancel", reset)
      preference.removeEventListener("change", reset)
      window.removeEventListener("blur", reset)
    }
  }, [failed, src])
  const srcSet = [480, 800, 1200]
    .map((width) => `${src.replace(/w=\d+/, `w=${width}`)} ${width}w`)
    .join(", ")
  return (
    <div
      ref={ref}
      className={`clarity-image relative overflow-hidden bg-charcoal ${className}`}
    >
      {failed ? (
        <div className="flex h-full min-h-64 items-center justify-center p-8 text-center font-serif text-2xl text-ivory/80">
          Avance Law Partners
        </div>
      ) : (
        <>
          <img
            src={src}
            srcSet={srcSet}
            sizes="(min-width: 1024px) 48vw, 100vw"
            alt={alt}
            width={1200}
            height={1000}
            loading={priority ? "eager" : "lazy"}
            fetchPriority={priority ? "high" : "auto"}
            decoding="async"
            onError={() => setFailed(true)}
            className="clarity-base h-full w-full object-cover"
          />
          <div
            aria-hidden="true"
            className="clarity-colour pointer-events-none absolute inset-0"
          >
            <img
              src={src}
              srcSet={srcSet}
              sizes="(min-width: 1024px) 48vw, 100vw"
              alt=""
              width={1200}
              height={1000}
              decoding="async"
              loading={priority ? "eager" : "lazy"}
              className="h-full w-full object-cover"
            />
          </div>
        </>
      )}
    </div>
  )
}

export default WindowOfClarity
