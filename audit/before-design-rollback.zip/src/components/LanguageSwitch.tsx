import { useLanguage } from "../lib/i18n"

export function LanguageSwitch({ className = "" }: { className?: string }) {
  const { language, setLanguage } = useLanguage()
  const nextLanguage = language === "en" ? "bn" : "en"

  return (
    <button
      type="button"
      onClick={() => setLanguage(nextLanguage)}
      aria-pressed={language === "bn"}
      aria-label={
        language === "en"
          ? "Switch website language to Bengali"
          : "Switch website language to English"
      }
      data-no-translate
      className={`inline-flex h-11 min-w-11 shrink-0 items-center justify-center border border-current/30 px-2 text-xs font-semibold transition-colors hover:bg-gold/15 ${className}`}
    >
      {language === "en" ? "EN" : "বাংলা"}
    </button>
  )
}
