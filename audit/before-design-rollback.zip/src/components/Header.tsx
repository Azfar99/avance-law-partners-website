import { useEffect, useRef, useState } from "react"
import { Menu, X } from "lucide-react"
import { useRouter } from "../lib/router"
import { useChrome } from "../lib/chrome"
import { AppLink, ButtonLink, Container } from "./ui"
import { LogoLockupCompact } from "./Logo"
import { LanguageSwitch } from "./LanguageSwitch"

const NAV = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Lawyers", to: "/lawyers" },
  { label: "Practice areas", to: "/services" },
]
const MOBILE_NAV = [
  ...NAV,
  { label: "Our approach", to: "/approach" },
  { label: "Contact", to: "/contact" },
]
const isActive = (path: string, to: string) =>
  to === "/" ? path === "/" : path === to || path.startsWith(`${to}/`)

export function Header() {
  const { path } = useRouter()
  const { heroTone } = useChrome()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const dialog = useRef<HTMLDialogElement>(null)
  const trigger = useRef<HTMLButtonElement>(null)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])
  useEffect(() => {
    setOpen(false)
  }, [path])
  useEffect(() => {
    const breakpoint = window.matchMedia("(min-width: 1024px)")
    const closeOnDesktop = () => {
      if (breakpoint.matches) setOpen(false)
    }
    breakpoint.addEventListener("change", closeOnDesktop)
    return () => breakpoint.removeEventListener("change", closeOnDesktop)
  }, [])
  useEffect(() => {
    const element = dialog.current
    if (!element) return
    if (!open) {
      if (element.open) element.close()
      return
    }
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    if (!element.open) element.showModal()
    return () => {
      if (element.open) element.close()
      document.body.style.overflow = previousOverflow
      if (window.matchMedia("(max-width: 1023px)").matches)
        trigger.current?.focus({ preventScroll: true })
    }
  }, [open])
  const onLight = scrolled || heroTone === "light"
  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 border-b transition-colors duration-200 ${
          onLight
            ? "border-line-light bg-ivory text-obsidian"
            : "border-ivory/15 bg-obsidian text-ivory"
        }`}
      >
        <Container className="flex h-20 items-center justify-between gap-3">
          <AppLink to="/" className="min-w-0">
            <LogoLockupCompact onLight={onLight} />
          </AppLink>
          <nav
            aria-label="Primary"
            className="hidden items-center gap-6 lg:flex"
          >
            {NAV.map((item) => (
              <AppLink
                key={item.to}
                to={item.to}
                aria-current={isActive(path, item.to) ? "page" : undefined}
                className={`border-b py-3 text-sm font-medium transition-colors ${
                  isActive(path, item.to)
                    ? "border-gold"
                    : "border-transparent hover:border-gold"
                }`}
              >
                {item.label}
              </AppLink>
            ))}
          </nav>
          <div className="flex shrink-0 items-center gap-2 lg:gap-3">
            <ButtonLink to="/contact" className="hidden lg:inline-flex">
              Make an enquiry
            </ButtonLink>
            <LanguageSwitch />
            <button
              ref={trigger}
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              aria-expanded={open}
              aria-controls="site-menu"
              className="inline-flex h-11 w-11 items-center justify-center lg:hidden"
            >
              <Menu aria-hidden size={24} strokeWidth={1.5} />
            </button>
          </div>
        </Container>
      </header>
      <dialog
        ref={dialog}
        id="site-menu"
        aria-label="Site menu"
        onCancel={() => setOpen(false)}
        onClose={() => setOpen(false)}
        className="site-menu"
        onKeyDown={(event) => {
          if (event.key !== "Tab") return
          const items = Array.from(
            event.currentTarget.querySelectorAll<HTMLElement>(
              "a[href], button:not([disabled])",
            ),
          )
          const first = items[0]
          const last = items[items.length - 1]
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault()
            last?.focus()
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault()
            first?.focus()
          }
        }}
      >
        <div className="flex items-center justify-between gap-3 border-b border-ivory/20 pb-5">
          <LogoLockupCompact />
          <button
            type="button"
            autoFocus
            aria-label="Close menu"
            onClick={() => setOpen(false)}
            className="flex h-11 w-11 shrink-0 items-center justify-center"
          >
            <X aria-hidden size={24} />
          </button>
        </div>
        <nav aria-label="Mobile" className="mt-5 flex flex-col">
          {MOBILE_NAV.map((item) => (
            <AppLink
              key={item.to}
              to={item.to}
              onNavigate={() => setOpen(false)}
              aria-current={isActive(path, item.to) ? "page" : undefined}
              className={`border-b border-ivory/20 py-3 font-serif text-3xl ${
                isActive(path, item.to) ? "text-gold" : "text-ivory"
              }`}
            >
              {item.label}
            </AppLink>
          ))}
        </nav>
        <p className="mt-7 text-sm text-ivory/70">
          Avance Law Partners · Dhaka, Bangladesh
        </p>
      </dialog>
    </>
  )
}

export default Header
