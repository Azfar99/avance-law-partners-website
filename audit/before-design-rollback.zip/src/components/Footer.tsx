import { ArrowRight } from "lucide-react"
import { useSiteSettings } from "../lib/hooks"
import { AppLink, ButtonLink, Container } from "./ui"
import { LogoFull } from "./Logo"
import { useRouter } from "../lib/router"

const NAV = [
  { label: "About the firm", to: "/about" },
  { label: "Our approach", to: "/approach" },
  { label: "Our lawyers", to: "/lawyers" },
  { label: "Contact", to: "/contact" },
]

const PRACTICE_AREAS = [
  { label: "Corporate & Company Law", to: "/services/corporate-company-law" },
  {
    label: "Commercial Advisory",
    to: "/services/commercial-business-advisory",
  },
  { label: "Arbitration & ADR", to: "/services/arbitration-adr" },
  {
    label: "Litigation & Dispute Resolution",
    to: "/services/litigation-and-dispute-resolution",
  },
]

const LEGAL = [
  { label: "Privacy Policy", to: "/privacy" },
  { label: "Legal Disclaimer", to: "/disclaimer" },
  { label: "Terms of Use", to: "/terms" },
]

export function Footer() {
  const { settings } = useSiteSettings()
  const { path } = useRouter()

  return (
    <footer className="bg-obsidian text-ivory">
      {path !== "/contact" && (
        <div className="border-b border-ivory/20">
          <Container className="flex flex-col gap-6 py-10 lg:flex-row lg:items-center lg:justify-between lg:py-12">
            <div className="max-w-2xl">
              <p className="eyebrow text-gold">Avance Law Partners</p>
              <h2 className="mt-3 max-w-xl font-serif text-[clamp(1.9rem,3.5vw,2.8rem)] leading-tight text-ivory">
                Tell us what you need help with.
              </h2>
            </div>
            <ButtonLink
              to="/contact"
              variant="gold"
              size="lg"
              withArrow
              className="w-full sm:w-fit"
            >
              Speak with counsel
            </ButtonLink>
          </Container>
        </div>
      )}

      <Container className="grid gap-8 py-10 sm:grid-cols-2 lg:grid-cols-[1.1fr_.75fr_1fr_.9fr] lg:gap-8 lg:py-12">
        <div className="max-w-xs">
          <LogoFull className="w-[150px] sm:w-[168px]" />
          <p className="mt-6 font-serif text-[19px] leading-snug text-ivory/85">
            {settings.tagline || "Legal excellence. Practical solutions."}
          </p>
          <p className="mt-4 text-[14px] leading-relaxed text-ivory/55">
            Trusted legal counsel for companies, institutions and individuals
            since {settings.established || "1998"}.
          </p>
        </div>

        <nav aria-label="Explore" className="flex flex-col gap-3">
          <p className="eyebrow mb-2 text-gold">Explore</p>
          {NAV.map((item) => (
            <AppLink
              key={item.to}
              to={item.to}
              className="inline-flex min-h-9 w-fit items-center text-sm text-ivory/75 transition-colors hover:text-gold"
            >
              {item.label}
            </AppLink>
          ))}
        </nav>

        <nav aria-label="Practice areas" className="flex flex-col gap-3">
          <p className="eyebrow mb-2 text-gold">Practice areas</p>
          {PRACTICE_AREAS.map((item) => (
            <AppLink
              key={item.to}
              to={item.to}
              className="inline-flex min-h-9 w-fit items-center text-sm text-ivory/75 transition-colors hover:text-gold"
            >
              {item.label}
            </AppLink>
          ))}
          <AppLink
            to="/services"
            className="mt-2 inline-flex w-fit items-center gap-2 text-[14px] font-semibold text-ivory transition-colors hover:text-gold"
          >
            <span>All practice areas</span>
            <ArrowRight aria-hidden size={15} strokeWidth={1.7} />
          </AppLink>
        </nav>

        <div>
          <p className="eyebrow mb-4 text-gold">Office</p>
          <address className="not-italic text-[14px] leading-relaxed text-ivory/70">
            <span className="block">{settings.address_line_1}</span>
            <span className="block">{settings.address_line_2}</span>
            <span className="block">{settings.address_line_3}</span>
          </address>
          <p className="mt-5 text-[12px] font-semibold uppercase tracking-[.14em] text-ivory/70">
            Dhaka, Bangladesh
          </p>
        </div>
      </Container>

      <div className="border-t border-line-dark">
        <Container className="flex flex-col gap-4 py-6 text-[12px] text-ivory/50 sm:flex-row sm:items-center sm:justify-between">
          <p>
            {settings.footer_text ||
              "© Avance Law Partners. All rights reserved."}
          </p>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {LEGAL.map((item) => (
              <AppLink
                key={item.to}
                to={item.to}
                className="transition-colors hover:text-ivory"
              >
                {item.label}
              </AppLink>
            ))}
          </div>
        </Container>
      </div>
    </footer>
  )
}
