import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

export const buttonVariants = cva(
  "group inline-flex max-w-full items-center justify-center gap-2 rounded-[2px] border font-sans font-semibold leading-snug transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:pointer-events-none disabled:opacity-55",
  {
    variants: {
      variant: {
        gold: "border-gold bg-gold text-obsidian hover:bg-[#d8b32e] active:bg-gold-deep",
        "outline-dark":
          "border-charcoal/30 text-charcoal hover:border-charcoal hover:bg-charcoal/[0.04]",
        "outline-light":
          "border-ivory/35 text-ivory hover:border-ivory hover:bg-ivory/10",
        ghost:
          "border-transparent bg-transparent text-charcoal hover:bg-charcoal/[0.04]",
      },
      size: {
        md: "min-h-[48px] px-5 py-3 text-[14px]",
        lg: "min-h-[52px] px-6 py-3 text-[14px]",
        icon: "h-11 w-11 p-0 text-base",
      },
    },
    defaultVariants: {
      variant: "gold",
      size: "md",
    },
  },
)

export interface ButtonProps
  extends React.ComponentProps<"button">,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonProps) {
  const Component = asChild ? Slot : "button"

  return (
    <Component
      data-slot="button"
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  )
}
