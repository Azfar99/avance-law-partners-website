import type { ButtonHTMLAttributes, ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { useRouter } from "../lib/router";
import { useReveal } from "../lib/useReveal";
import { Button as ShadcnButton } from "./ui/button";
import { cn } from "../lib/utils";

/* ---------- Navigation-aware link ---------- */

export function AppLink({
  to,
  children,
  className = "",
  onNavigate,
}: {
  to: string;
  children: ReactNode;
  className?: string;
  onNavigate?: () => void;
}) {
  const { navigate } = useRouter();
  return (
    <a
      href={`#${to}`}
      className={className}
      onClick={(e) => {
        // Allow modified clicks to behave normally.
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        navigate(to);
        onNavigate?.();
      }}
    >
      {children}
    </a>
  );
}

/* ---------- Buttons ---------- */

type ButtonBase = {
  children: ReactNode;
  variant?: "gold" | "outline-dark" | "outline-light" | "ghost";
  size?: "md" | "lg" | "icon";
  className?: string;
  withArrow?: boolean;
};

function ButtonInner({
  children,
  withArrow,
}: {
  children: ReactNode;
  withArrow?: boolean;
}) {
  return (
    <span className="inline-flex items-center gap-2">
      {children}
      {withArrow && (
        <span aria-hidden className="btn-arrow inline-flex transition-transform duration-200">
          <ArrowRight size={14} strokeWidth={1.8} />
        </span>
      )}
    </span>
  );
}

export function ButtonLink({
  to,
  variant = "gold",
  size = "md",
  className = "",
  withArrow,
  children,
}: ButtonBase & { to: string }) {
  const { navigate } = useRouter();
  return (
    <ShadcnButton
      asChild
      variant={variant}
      size={size}
      className={cn("[&:hover_.btn-arrow]:translate-x-[3px]", className)}
    >
      <a
        href={`#${to}`}
        onClick={(e) => {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
          e.preventDefault();
          navigate(to);
        }}
      >
        <ButtonInner withArrow={withArrow}>{children}</ButtonInner>
      </a>
    </ShadcnButton>
  );
}

export function Button({
  variant = "gold",
  size = "md",
  className = "",
  withArrow,
  children,
  ...rest
}: ButtonBase & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <ShadcnButton
      {...rest}
      variant={variant}
      size={size}
      className={cn("[&:hover_.btn-arrow]:translate-x-[3px]", className)}
    >
      <ButtonInner withArrow={withArrow}>{children}</ButtonInner>
    </ShadcnButton>
  );
}

/* ---------- Inline text link with animated underline ---------- */

export function InlineLink({
  to,
  children,
  tone = "dark",
}: {
  to: string;
  children: ReactNode;
  tone?: "dark" | "gold" | "light";
}) {
  const toneCls =
    tone === "gold"
      ? "text-gold-deep decoration-gold/50 hover:decoration-gold-deep"
      : tone === "light"
        ? "text-ivory decoration-ivory/40 hover:decoration-ivory"
        : "text-charcoal decoration-charcoal/30 hover:decoration-charcoal";
  return (
    <AppLink
      to={to}
      className={`group inline-flex items-center gap-2 font-semibold underline underline-offset-[6px] decoration-1 transition-colors ${toneCls}`}
    >
      {children}
      <span aria-hidden className="inline-flex transition-transform duration-200 group-hover:translate-x-[3px]">
        <ArrowRight size={14} strokeWidth={1.8} />
      </span>
    </AppLink>
  );
}

/* ---------- Layout container ---------- */

export function Container({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-16 ${className}`}>
      {children}
    </div>
  );
}

/* ---------- Eyebrow label ---------- */

export function Eyebrow({
  children,
  tone = "gold",
}: {
  children: ReactNode;
  tone?: "gold" | "muted" | "light";
}) {
  const c =
    tone === "gold"
      ? "text-gold-deep"
      : tone === "light"
        ? "text-ivory/70"
        : "text-ink-60";
  return <p className={`eyebrow ${c}`}>{children}</p>;
}

/* ---------- Reveal-on-scroll wrapper ---------- */

export function Reveal({
  children,
  className = "",
  as: As = "div",
  style,
}: {
  children: ReactNode;
  className?: string;
  as?: "div" | "section" | "li" | "article";
  style?: React.CSSProperties;
}) {
  const ref = useReveal<HTMLDivElement>();
  return (
    // @ts-expect-error dynamic element
    <As ref={ref} className={`reveal-on-view ${className}`} style={style}>
      {children}
    </As>
  );
}
