import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "group inline-flex shrink-0 items-center justify-center gap-2 border font-sans font-semibold uppercase tracking-[0.08em] transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:pointer-events-none disabled:opacity-55",
  {
    variants: {
      variant: {
        gold: "border-gold bg-gold text-obsidian hover:bg-[#d8b32e] active:bg-gold-deep",
        "outline-dark":
          "border-charcoal/30 text-charcoal hover:border-charcoal hover:bg-charcoal/[0.04]",
        "outline-light":
          "border-ivory/35 text-ivory hover:border-ivory hover:bg-ivory/10",
        ghost:
          "border-transparent bg-transparent text-charcoal hover:bg-charcoal/[0.04]",
      },
      size: {
        md: "min-h-[48px] px-6 text-[11px]",
        lg: "min-h-[54px] px-7 text-[12px]",
        icon: "h-10 w-10 p-0 text-base",
      },
    },
    defaultVariants: {
      variant: "gold",
      size: "md",
    },
  },
);

export interface ButtonProps
  extends React.ComponentProps<"button">,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonProps) {
  const Component = asChild ? Slot : "button";

  return (
    <Component
      data-slot="button"
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}
