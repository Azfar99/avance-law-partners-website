import { useEffect } from "react";
import { updatePageSEO } from "../lib/seo";

interface SEOHeadProps {
  title: string;
  description?: string;
  ogImage?: string;
  canonicalPath?: string;
}

export default function SEOHead({ title, description, ogImage, canonicalPath }: SEOHeadProps) {
  useEffect(() => {
    updatePageSEO({
      title,
      description:
        description ||
        "Avance Law Partners — providing trusted corporate, commercial, regulatory, and dispute resolution counsel in Dhaka, Bangladesh since 1998.",
      ogImage: ogImage || "/images/avance-law-partners-logo.png",
      canonicalUrl: canonicalPath ? `https://avancelawpartners.info/#${canonicalPath}` : undefined,
    });
  }, [title, description, ogImage, canonicalPath]);

  return null;
}
