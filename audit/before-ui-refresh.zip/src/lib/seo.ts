// Avance Law Partners — Dynamic SEO Meta Tag Injector
export function updatePageSEO({
  title,
  description,
  ogImage,
  canonicalUrl,
}: {
  title?: string;
  description?: string;
  ogImage?: string;
  canonicalUrl?: string;
}) {
  if (title) {
    document.title = title.includes("Avance Law Partners") ? title : `${title} | Avance Law Partners`;
  }

  if (description) {
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement("meta");
      metaDesc.setAttribute("name", "description");
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute("content", description);
  }

  if (ogImage) {
    let ogImg = document.querySelector('meta[property="og:image"]');
    if (!ogImg) {
      ogImg = document.createElement("meta");
      ogImg.setAttribute("property", "og:image");
      document.head.appendChild(ogImg);
    }
    ogImg.setAttribute("content", ogImage);
  }

  if (canonicalUrl) {
    let linkCan = document.querySelector('link[rel="canonical"]');
    if (!linkCan) {
      linkCan = document.createElement("link");
      linkCan.setAttribute("rel", "canonical");
      document.head.appendChild(linkCan);
    }
    linkCan.setAttribute("href", canonicalUrl);
  }
}
