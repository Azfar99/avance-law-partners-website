// Avance Law Partners — Auth Context & Helpers
import { useEffect, useState } from "react";
import { supabase, getStoredSession } from "./supabase";

export interface AdminUser {
  id: string;
  email: string;
  role: string;
}

export function useAuth() {
  const [user, setUser] = useState<AdminUser | null>(() => {
    const s = getStoredSession();
    return s?.user || null;
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => {
      data?.subscription?.unsubscribe();
    };
  }, []);

  const login = async (email: string, password?: string) => {
    setLoading(true);
    const res = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    return res;
  };

  const logout = async () => {
    setLoading(true);
    await supabase.auth.signOut();
    setUser(null);
    setLoading(false);
  };

  return { user, loading, login, logout, isAuthenticated: Boolean(user) };
}
