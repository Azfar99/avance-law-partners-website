import { RouterProvider, useRouter } from "./lib/router";
import { ChromeProvider } from "./lib/chrome";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import Home from "./pages/Home";
import About from "./pages/About";
import Approach from "./pages/Approach";
import Lawyers from "./pages/Lawyers";
import LawyerProfile from "./pages/LawyerProfile";
import Services from "./pages/Services";
import ServiceDetail from "./pages/ServiceDetail";
import Contact from "./pages/Contact";
import Legal from "./pages/Legal";
import { NotFound } from "./pages/NotFound";
import { LanguageProvider } from "./lib/i18n";

// Admin views
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminSiteSettings from "./pages/admin/AdminSiteSettings";
import AdminLawyersList from "./pages/admin/AdminLawyersList";
import AdminLawyerEdit from "./pages/admin/AdminLawyerEdit";
import AdminServicesList from "./pages/admin/AdminServicesList";
import AdminServiceEdit from "./pages/admin/AdminServiceEdit";
import AdminEnquiries from "./pages/admin/AdminEnquiries";
import AdminEnquiryDetail from "./pages/admin/AdminEnquiryDetail";
import AdminPageEditor from "./pages/admin/AdminPageEditor";
import AdminMedia from "./pages/admin/AdminMedia";
import AdminLegalPages from "./pages/admin/AdminLegalPages";
import AdminSEO from "./pages/admin/AdminSEO";

function Routes() {
  const { path } = useRouter();
  const seg = path.split("/").filter(Boolean);

  // Admin Routes
  if (seg[0] === "admin") {
    if (import.meta.env.VITE_PUBLIC_PREVIEW === "true") return <NotFound />
    if (seg.length === 1) return <AdminDashboard />;
    if (seg[1] === "login") return <AdminLogin />;
    if (seg[1] === "settings") return <AdminSiteSettings />;
    if (seg[1] === "lawyers") {
      if (seg[2]) return <AdminLawyerEdit slug={seg[2]} />;
      return <AdminLawyersList />;
    }
    if (seg[1] === "services") {
      if (seg[2]) return <AdminServiceEdit slug={seg[2]} />;
      return <AdminServicesList />;
    }
    if (seg[1] === "enquiries") {
      if (seg[2]) return <AdminEnquiryDetail id={seg[2]} />;
      return <AdminEnquiries />;
    }
    if (seg[1] === "pages") return <AdminPageEditor />;
    if (seg[1] === "media") return <AdminMedia />;
    if (seg[1] === "legal") return <AdminLegalPages />;
    if (seg[1] === "seo") return <AdminSEO />;
    return <AdminDashboard />;
  }

  // Public Routes
  let page;
  if (path === "/") page = <Home />;
  else if (path === "/about") page = <About />;
  else if (path === "/approach") page = <Approach />;
  else if (path === "/lawyers") page = <Lawyers />;
  else if (seg[0] === "lawyers" && seg[1]) page = <LawyerProfile slug={seg[1]} />;
  else if (path === "/services") page = <Services />;
  else if (seg[0] === "services" && seg[1]) page = <ServiceDetail slug={seg[1]} />;
  else if (path === "/contact") page = <Contact />;
  else if (path === "/privacy") page = <Legal kind="privacy" />;
  else if (path === "/disclaimer") page = <Legal kind="disclaimer" />;
  else if (path === "/terms") page = <Legal kind="terms" />;
  else page = <NotFound />;

  return page;
}

function AppShell() {
  const { path } = useRouter();
  const isAdmin = path.startsWith("/admin");

  if (isAdmin) {
    return <Routes />;
  }

  return (
    <LanguageProvider>
      <ChromeProvider>
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-[5px] focus:bg-gold focus:px-4 focus:py-2 focus:font-semibold focus:text-obsidian"
        >
          Skip to content
        </a>
        <Header />
        <main id="main-content" tabIndex={-1} className="focus:outline-none">
          <Routes />
        </main>
        <Footer />
      </ChromeProvider>
    </LanguageProvider>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AppShell />
    </RouterProvider>
  );
}
