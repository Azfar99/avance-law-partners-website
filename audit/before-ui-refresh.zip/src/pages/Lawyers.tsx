import { type UIEvent, useEffect, useRef } from "react"
import { ArrowRight } from "lucide-react"
import { lawyers as defaultLawyers } from "../lib/content"
import { useLawyers, type DBLawyer } from "../lib/hooks"
import { AppLink, Container, Reveal } from "../components/ui"
import { Breadcrumb, PortraitPlaceholder } from "../components/parts"
import { useHeroTone } from "../lib/chrome"
import SEOHead from "../components/SEOHead"

function LawyerEntry({
  lawyer,
  n,
  offset,
}: {
  lawyer: DBLawyer
  n: number
  offset?: boolean
}) {
  return (
    <article
      className={`h-full rounded-[10px] border border-obsidian/10 bg-white/45 p-3 shadow-[0_12px_36px_rgba(24,21,16,0.07)] transition-colors duration-300 hover:border-gold-deep/40 sm:p-4 md:rounded-none md:border-0 md:bg-transparent md:p-0 md:shadow-none md:hover:border-transparent ${offset ? "lg:mt-24" : ""}`}
    >
      <AppLink
        to={`/lawyers/${lawyer.slug}`}
        className="group block h-full rounded-sm focus-visible:outline-offset-4"
      >
        <div className="relative overflow-hidden rounded-[5px] border border-obsidian/10 bg-stone">
          <span className="absolute left-3 top-3 z-10 inline-flex h-8 min-w-8 items-center justify-center rounded-full border border-gold/40 bg-obsidian/85 px-2 font-sans text-[11px] font-semibold tracking-[0.08em] text-gold shadow-sm">
            0{n}
          </span>
          <div className="transition-transform duration-500 group-hover:scale-[1.02]">
            <PortraitPlaceholder
              lawyer={lawyer}
              loading={n === 1 ? "eager" : "lazy"}
            />
          </div>
        </div>
        <div className="mt-4 border-t border-obsidian/75 pt-4 md:mt-5 md:border-obsidian md:pt-4">
          {!lawyer.published && (
            <span className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.12em] text-gold-deep">
              Draft · unpublished
            </span>
          )}
          <h2 className="font-serif text-[clamp(1.35rem,6vw,1.75rem)] font-semibold leading-[1.12] tracking-[-0.01em] text-obsidian md:text-[28px]">
            {lawyer.name || (
              <span className="text-ink-60">Name to be confirmed</span>
            )}
          </h2>
          {lawyer.designation && (
            <p className="mt-2 text-[12px] font-semibold leading-relaxed tracking-[0.06em] text-gold-deep">{lawyer.designation}</p>
          )}
          {lawyer.professional_title && (
            <p className="mt-1 text-[13px] leading-relaxed text-ink-60">{lawyer.professional_title}</p>
          )}
          <p className="mt-3 min-h-11 line-clamp-2 text-[14px] leading-relaxed text-charcoal/75">
            {lawyer.biography ||
              "View the full professional profile and practice details."}
          </p>
          <span className="mt-5 flex items-center justify-between rounded-[4px] border border-gold-deep/35 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-[0.11em] text-gold-deep transition-colors group-hover:border-gold group-hover:bg-gold group-hover:text-obsidian sm:px-4 sm:text-[11px]">
            <span>View full profile</span>
            <ArrowRight aria-hidden className="ml-3 shrink-0" size={15} strokeWidth={1.7} />
          </span>
        </div>
      </AppLink>
    </article>
  )
}

export default function Lawyers() {
  useHeroTone("light")
  const { lawyers } = useLawyers()
  const progressThumbRef = useRef<HTMLSpanElement | null>(null)
  const scrollFrameRef = useRef<number | null>(null)
  const displayList =
    lawyers.length > 0
      ? lawyers
      : defaultLawyers.map((l) => ({
          ...l,
          display_order: 1,
        }))

  function updateScrollProgress(event: UIEvent<HTMLDivElement>) {
    const rail = event.currentTarget
    if (scrollFrameRef.current !== null) return

    scrollFrameRef.current = window.requestAnimationFrame(() => {
      scrollFrameRef.current = null
      const scrollableDistance = rail.scrollWidth - rail.clientWidth
      const progress =
        scrollableDistance > 0 ? rail.scrollLeft / scrollableDistance : 0
      if (progressThumbRef.current) {
        progressThumbRef.current.style.transform = `translateX(${progress * 194}%)`
      }
    })
  }

  useEffect(
    () => () => {
      if (scrollFrameRef.current !== null) {
        window.cancelAnimationFrame(scrollFrameRef.current)
      }
    },
    [],
  )

  return (
    <section className="bg-ivory">
      <SEOHead
        title="Our Lawyers & Legal Counsel"
        description="Direct access to experienced advocates and legal counsel at Avance Law Partners in Dhaka, Bangladesh."
        canonicalPath="/lawyers"
      />
      <Container className="pb-24 pt-32 lg:pb-32 lg:pt-40">
        <div className="[&_[aria-current]]:text-charcoal">
          <Breadcrumb
            trail={[{ label: "Home", to: "/" }, { label: "Lawyers" }]}
          />
        </div>

        {/* Editorial masthead with a rule and running head */}
        <div className="mt-10">
          <div className="flex items-baseline justify-between border-b border-obsidian pb-4">
            <p className="eyebrow text-gold-deep">Our lawyers</p>
            <p className="text-[13px] uppercase tracking-[0.16em] text-ink-60">
              {displayList.length} profiles
            </p>
          </div>
          <h1 className="mt-8 max-w-4xl font-serif text-[clamp(2.4rem,6vw,5rem)] font-medium leading-[1.02] tracking-[-0.02em] text-obsidian">
            The people behind the practice.
          </h1>
          <p className="mt-6 max-w-lg text-[18px] leading-relaxed text-charcoal/80">
            Direct access to experienced counsel who stay close to your matter —
            from the first conversation through to resolution.
          </p>
        </div>

        {/* Swipeable profiles on mobile; staggered grid on larger screens. */}
        <div className="mb-4 mt-10 flex items-center justify-between md:hidden">
          <p className="eyebrow text-gold-deep">Meet our lawyers</p>
          <span className="inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-60">
            <span>Swipe profiles</span>
            <span aria-hidden className="text-base leading-none text-gold-deep">↔</span>
          </span>
        </div>
        <div
          className="-mx-5 flex snap-x snap-proximity gap-4 overflow-x-auto overscroll-x-contain px-5 pb-3 pr-10 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden sm:-mx-8 sm:gap-5 sm:px-8 md:mt-16 md:mx-0 md:grid md:snap-none md:grid-cols-2 md:gap-x-10 md:gap-y-14 md:overflow-visible md:px-0 md:pb-0 md:pr-0 md:[scrollbar-width:auto] lg:grid-cols-3"
          role="region"
          aria-label="Lawyer profiles. Swipe horizontally to browse profiles."
          onScroll={updateScrollProgress}
        >
          {displayList.map((l, i) => (
            <Reveal
              key={l.slug}
              className="w-[calc(100vw-80px)] min-w-[240px] max-w-[360px] shrink-0 snap-start md:w-auto md:min-w-0 md:max-w-none"
              style={{ animationDelay: `${i * 70}ms` }}
            >
              <LawyerEntry lawyer={l} n={i + 1} offset={i === 1} />
            </Reveal>
          ))}
        </div>

        <div className="mt-3 md:hidden" aria-hidden="true">
          <div className="h-1.5 overflow-hidden rounded-full bg-gold-deep/15 shadow-inner">
            <span
              ref={progressThumbRef}
              className="block h-full w-[34%] rounded-full bg-gradient-to-r from-gold-deep via-gold to-[#ead078] shadow-[0_0_12px_rgb(201_162_39_/_0.35)] will-change-transform"
              style={{ transform: "translateX(0%)" }}
            />
          </div>
          <div className="mt-2 flex items-center justify-between text-[9px] font-semibold uppercase tracking-[0.14em] text-ink-60">
            <span>Swipe profiles</span>
            <span>{String(displayList.length).padStart(2, "0")} profiles</span>
          </div>
        </div>

        <p className="mt-20 max-w-2xl border-t border-line-light pt-8 text-[14px] leading-relaxed text-ink-60">
          Additional profiles, designations, and approved credentials can be
          updated directly by the firm administrator without technical
          modification.
        </p>
      </Container>
    </section>
  )
}
