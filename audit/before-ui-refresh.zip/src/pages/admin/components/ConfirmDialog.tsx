export default function ConfirmDialog({
  title,
  message,
  confirmLabel = "Delete",
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-obsidian/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-lg border border-line-light bg-ivory p-6 shadow-2xl">
        <h3 className="font-serif text-2xl text-obsidian">{title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-charcoal/85">{message}</p>
        <div className="mt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="rounded px-4 py-2 text-sm font-semibold text-charcoal hover:bg-stone transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="rounded bg-red-800 px-4 py-2 text-sm font-semibold text-ivory hover:bg-red-900 transition-colors"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
